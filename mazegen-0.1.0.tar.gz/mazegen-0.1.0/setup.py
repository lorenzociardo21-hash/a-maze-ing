from setuptools import setup, find_packages

setup(
    name="mazegen",
    version="0.1.0",
    description="A reusable maze generation library implementing DFS, Prim's and Kruskal's algorithms.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="lciardo, lgreco",
    python_requires=">=3.10",
    packages=find_packages(include=["maze_gen", "maze_gen.*"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
