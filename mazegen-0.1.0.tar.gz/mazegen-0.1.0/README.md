# mazegen

A reusable Python package for maze generation using DFS, Prim's, and Kruskal's algorithms.

## Installation

```bash
pip install mazegen-0.1.0-py3-none-any.whl
```

## Usage

```python
from maze_gen.generator import MazeGenerator

gen = MazeGenerator(
    width=20,
    height=15,
    entry=(0, 0),
    exit=(19, 14),
    perfect=True,
    seed="None",
)

grid, seed = gen.generate_maze_kruskal()
# or: gen.generate_maze_prims()
# or: gen.generate_maze_dfs()

print(f"Seed used: {seed}")
print(f"Grid: {len(grid)} rows x {len(grid[0])} cols")
```
